# 创作实验室 Android App

一个面向小红书创作者的原生 Android 运营工作台（Kotlin + Jetpack Compose）。

## 当前包含
- 首页经营概览
- 赛道初筛与商业化路径参考
- 分类选题库
- AI 笔记生成（OpenAI-compatible Chat Completions API）
- 笔记本地保存
- 浏览、点赞、收藏、涨粉、收入数据记录
- API 地址、模型和密钥设置
- 本地加密 SharedPreferences 保存设置及运营数据

## 构建环境
- Android Studio Ladybug 或更新版本
- JDK 17
- Android SDK Platform 35
- Gradle 8.9+（由 Android Studio 根据 Android Gradle Plugin 8.7.3 自动配置）

## 构建 APK
1. 用 Android Studio 打开本目录 `CreatorLab`。
2. 等待 Gradle Sync 完成。
3. 选择 Build > Build Bundle(s) / APK(s) > Build APK(s)。
4. 安装生成的 debug APK。

命令行构建：`gradle assembleDebug`（需本机已安装 Android SDK 和 Gradle）。

## 配置 AI
打开 App 右上角齿轮，填写：
- API Base URL：默认 `https://api.openai.com/v1`
- 模型名称：填写账户可用的模型，例如 `gpt-4o-mini`（以服务商当前可用模型为准）
- API Key：填写你自己的密钥

应用调用 `POST {API Base URL}/chat/completions`。支持兼容该接口格式的服务商。API 使用费用由服务商按其政策收取。密钥保存在 AndroidX EncryptedSharedPreferences 中，但任何本地客户端密钥仍应视为有设备访问风险；不要在多人共用设备上保存，也不要将 APK 分发给他人并附带自己的密钥。

## 重要说明
- 当前版本是可继续扩展的第一版，不会自动登录或操作小红书账号，也不会自动发布、抓取后台数据或绕过平台限制。
- 赛道评估是定性参考，不是实时市场数据；选题需要结合实际搜索结果验证。
- AI生成内容必须人工核验，不得虚构体验、收入或数据。
- 当前开发环境没有 Android SDK/Gradle，因此这里提供完整 Android Studio 项目源码，不能在此环境直接产出并验证 APK。用 Android Studio 构建后即可安装到 Android 手机。
