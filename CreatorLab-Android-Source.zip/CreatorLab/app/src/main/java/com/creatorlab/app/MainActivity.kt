package com.creatorlab.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

private val Ink = Color(0xFF20232B)
private val Muted = Color(0xFF777D89)
private val Red = Color(0xFFE85B68)
private val Canvas = Color(0xFFF6F6F8)
private val Green = Color(0xFF239B78)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = EncryptedSharedPreferences.create(
            this, "creator_lab_secure",
            MasterKey.Builder(this).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
        setContent { CreatorLabApp(prefs) }
    }
}

data class Post(val title: String, val body: String, val topic: String, val date: String)
data class Metric(val date: String, val views: Int, val likes: Int, val saves: Int, val followers: Int, val income: Double)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreatorLabApp(prefs: android.content.SharedPreferences) {
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf(0) }
    var posts by remember { mutableStateOf(loadPosts(prefs)) }
    var metrics by remember { mutableStateOf(loadMetrics(prefs)) }
    var apiBase by remember { mutableStateOf(prefs.getString("base", "https://api.openai.com/v1") ?: "") }
    var apiModel by remember { mutableStateOf(prefs.getString("model", "gpt-4o-mini") ?: "") }
    var apiKey by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
    var showAddMetric by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = lightColorScheme(primary = Red, secondary = Green, background = Canvas, surface = Color.White)) {
        Scaffold(
            containerColor = Canvas,
            topBar = {
                TopAppBar(
                    title = { Column { Text("创作实验室", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, color = Ink); Text("把内容做成一门生意", fontSize = 11.sp, color = Muted) } },
                    actions = { IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "设置", tint = Ink) }; Surface(color = Color(0xFFFFE9EC), shape = CircleShape, modifier = Modifier.padding(end = 12.dp)) { Text("CREATOR", color = Red, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp)) } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Canvas)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    val items = listOf("首页", "赛道", "选题", "创作", "数据")
                    val icons = listOf(Icons.Default.Home, Icons.Default.Insights, Icons.Default.Lightbulb, Icons.Default.EditNote, Icons.Default.Analytics)
                    items.forEachIndexed { i, label -> NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(icons[i], null) }, label = { Text(label, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Red, selectedTextColor = Red, indicatorColor = Color(0xFFFFE9EC))) }
                }
            }
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                when (tab) {
                    0 -> HomeScreen(posts.size, metrics, onGo = { tab = it })
                    1 -> StrategyScreen()
                    2 -> IdeasScreen(onUse = { tab = 3 })
                    3 -> CreateScreen(apiBase, apiModel, apiKey, onSave = { p -> posts = (listOf(p) + posts).take(100); savePosts(prefs, posts) })
                    4 -> AnalyticsScreen(metrics, onAdd = { showAddMetric = true }, posts = posts)
                }
            }
        }
        if (showAddMetric) AddMetricDialog(onDismiss = { showAddMetric = false }, onSave = { m -> metrics = (metrics + m).takeLast(100); saveMetrics(prefs, metrics); showAddMetric = false })
        if (showSettings) SettingsDialog(apiBase, apiModel, apiKey, onDismiss = { showSettings = false }, onSave = { b, m, k -> apiBase = b; apiModel = m; apiKey = k; prefs.edit().putString("base", b).putString("model", m).putString("key", k).apply(); showSettings = false })
    }
}

@Composable
fun ScreenColumn(content: @Composable ColumnScope.() -> Unit) { Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(14.dp), content = content) }

@Composable
fun HomeScreen(postCount: Int, metrics: List<Metric>, onGo: (Int) -> Unit) {
    val latest = metrics.lastOrNull()
    ScreenColumn {
        Surface(shape = RoundedCornerShape(24.dp), color = Ink, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("YOUR CREATOR BUSINESS", color = Color(0xFFFFA8B0), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                Text("从一个想法，\n到一份真实收入。", color = Color.White, fontSize = 27.sp, lineHeight = 35.sp, fontWeight = FontWeight.ExtraBold)
                Text("选方向 · 做内容 · 看数据 · 优化变现", color = Color(0xFFCFD1D8), fontSize = 12.sp)
                Button(onClick = { onGo(3) }, colors = ButtonDefaults.buttonColors(containerColor = Red), shape = RoundedCornerShape(14.dp)) { Text("开始创作", fontWeight = FontWeight.Bold); Icon(Icons.Default.ArrowForward, null, Modifier.padding(start = 6.dp)) }
            }
        }
        Text("经营概览", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("已保存笔记", postCount.toString(), "篇", Modifier.weight(1f))
            StatCard("累计浏览", (metrics.sumOf { it.views }).toString(), "次", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("累计收藏", metrics.sumOf { it.saves }.toString(), "次", Modifier.weight(1f))
            StatCard("记录收入", "¥" + String.format("%.0f", metrics.sumOf { it.income }), "元", Modifier.weight(1f))
        }
        Text("工作台", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink)
        listOf(Triple("分析赛道", "比较市场需求、竞争和变现方式", 1), Triple("寻找选题", "从用户问题出发建立内容库", 2), Triple("AI创作", "生成标题、正文和配音稿", 3), Triple("复盘数据", "记录笔记表现，找到有效内容", 4)).forEach { (title, desc, target) ->
            Surface(onClick = { onGo(target) }, color = Color.White, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).background(Color(0xFFFFEFF1), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) { Icon(listOf(Icons.Default.Insights, Icons.Default.Lightbulb, Icons.Default.EditNote, Icons.Default.Analytics)[target-1], null, tint = Red) }
                    Column(Modifier.weight(1f).padding(start = 12.dp)) { Text(title, fontWeight = FontWeight.Bold, color = Ink); Text(desc, color = Muted, fontSize = 11.sp) }
                    Icon(Icons.Default.ChevronRight, null, tint = Muted)
                }
            }
        }
        Text("今日提醒：先验证需求，再批量生产内容。", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(bottom = 10.dp))
    }
}

@Composable
fun StatCard(label: String, value: String, unit: String, modifier: Modifier = Modifier) {
    Surface(color = Color.White, shape = RoundedCornerShape(18.dp), modifier = modifier) { Column(Modifier.padding(15.dp)) { Text(label, color = Muted, fontSize = 11.sp); Row(verticalAlignment = Alignment.Bottom) { Text(value, color = Ink, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold); Text(unit, color = Muted, fontSize = 10.sp, modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)) } } }
}

@Composable
fun StrategyScreen() {
    val tracks = listOf(
        listOf("AI工具与效率", "大", "高", "很高", "教程、模板、软件合作"),
        listOf("副业实测", "大", "中高", "极高", "工具推广、数字产品、服务"),
        listOf("职场技能", "中大", "高", "高", "模板、课程、企业服务"),
        listOf("旅游与实用英语", "中大", "高", "中高", "攻略、语言服务、旅游合作"),
        listOf("考研学习", "中大", "中高", "高", "学习模板、资料、文具合作"),
        listOf("书影音与社会观察", "中", "中低", "中高", "品牌合作、出版合作")
    )
    ScreenColumn {
        PageHeading("赛道分析", "先选一个有需求、有付费场景的市场")
        Surface(color = Color(0xFFFFF1E8), shape = RoundedCornerShape(16.dp)) { Text("以下为定性初筛，不是实时平台数据。真正决策前，建议在小红书搜索关键词，抽样观察近期笔记和评论区。", color = Color(0xFF87512E), fontSize = 12.sp, modifier = Modifier.padding(14.dp)) }
        tracks.forEach { t ->
            Surface(color = Color.White, shape = RoundedCornerShape(17.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(t[0], color = Ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { Tag("流量 ${t[1]}"); Tag("变现 ${t[2]}"); Tag("竞争 ${t[3]}") }
                    Text("变现路径：${t[4]}", color = Muted, fontSize = 12.sp)
                }
            }
        }
        Text("建议初始测试：AI工具实操 + 真实副业实验。不要把多个不相关领域混在同一个账号。", color = Green, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
    }
}

@Composable
fun Tag(text: String) { Surface(color = Color(0xFFF1F2F5), shape = RoundedCornerShape(8.dp)) { Text(text, color = Color(0xFF555B66), fontSize = 10.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)) } }

@Composable
fun IdeasScreen(onUse: () -> Unit) {
    val categories = listOf("AI工具", "副业实测", "技能变现", "账号运营")
    val data = mapOf(
        "AI工具" to listOf("我测试了3款免费AI做PPT工具，结果差别有多大？", "不会设计，怎么用AI做一张小红书封面？", "把一篇长文章变成思维导图，我用了这套流程", "普通人怎么用AI整理一周的工作？", "AI简历生成器实测：哪些地方还得自己改？"),
        "副业实测" to listOf("零成本做数字产品，第一步究竟做什么？", "我拆解了一个线上兼职项目的真实成本", "网上月入过万的副业，先检查这5个风险", "不露脸账号有哪些真实的变现方式？", "如何判断一个副业项目是不是割韭菜？"),
        "技能变现" to listOf("如何制作一份能重复使用的Excel模板？", "英语基础一般，能提供哪些语言类服务？", "从需求到交付：一份旅游攻略怎么制作？", "PPT排版接单需要准备哪些作品？", "把自己的知识整理成数字产品的流程"),
        "账号运营" to listOf("新账号前20篇笔记，应该怎么安排？", "收藏很多但没人关注，问题可能出在哪？", "小红书笔记标题怎么写得具体而不夸张？", "如何用表格复盘每一篇笔记？", "一个账号怎样从流量走向稳定收入？")
    )
    var selected by remember { mutableStateOf(categories[0]) }
    ScreenColumn {
        PageHeading("选题中心", "从用户问题出发，不靠拍脑袋更新")
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) { categories.forEach { c -> FilterChip(selected = selected == c, onClick = { selected = c }, label = { Text(c) }) } }
        data[selected].orEmpty().forEachIndexed { i, title ->
            Surface(color = Color.White, shape = RoundedCornerShape(15.dp), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${i+1}", color = Red, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                    Text(title, modifier = Modifier.weight(1f).padding(horizontal = 12.dp), color = Ink, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    IconButton(onClick = onUse) { Icon(Icons.Default.Edit, "使用选题", tint = Red) }
                }
            }
        }
        Text("提示：发布前先搜索同类关键词，检查近30天内容、互动质量和评论区未被解决的问题。", color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun PageHeading(title: String, subtitle: String) { Column(verticalArrangement = Arrangement.spacedBy(4.dp)) { Text(title, color = Ink, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold); Text(subtitle, color = Muted, fontSize = 12.sp) } }

@Composable
fun CreateScreen(base: String, model: String, key: String, onSave: (Post) -> Unit) {
    var topic by remember { mutableStateOf("AI工具实操") }
    var audience by remember { mutableStateOf("想用AI提高效率的学生和职场新人") }
    var keyword by remember { mutableStateOf("免费AI工具") }
    var style by remember { mutableStateOf("真实测评、具体步骤、不夸大效果") }
    var result by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    ScreenColumn {
        PageHeading("AI笔记创作", "生成初稿，再用真实体验校准")
        OutlinedTextField(topic, { topic = it }, label = { Text("内容方向") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp))
        OutlinedTextField(audience, { audience = it }, label = { Text("目标读者") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp))
        OutlinedTextField(keyword, { keyword = it }, label = { Text("核心关键词 / 用户问题") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp))
        OutlinedTextField(style, { style = it }, label = { Text("内容风格与要求") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp))
        Button(onClick = {
            if (base.isBlank() || key.isBlank() || model.isBlank()) { error = "请先到「设置」填写AI接口地址、模型和API Key。"; return@Button }
            loading = true; error = ""; result = ""
            scope.launch {
                try {
                    val prompt = "你是严谨的小红书内容策划。请为方向：$topic；目标读者：$audience；关键词/问题：$keyword；风格：$style，创作一篇可发布前人工核验的小红书笔记。输出格式：1.三个标题备选 2.正文（有清晰结构、具体步骤、真实边界，不虚构个人经历或数据）3.封面大字 4.话题标签 5.配音稿。不要承诺收益，不编造测评结果。"
                    val answer = withContext(Dispatchers.IO) { callChatApi(base, model, key, prompt) }
                    result = answer
                    title = answer.lineSequence().firstOrNull { it.contains("标题") }?.take(50) ?: keyword
                } catch (e: Exception) { error = e.message ?: "生成失败，请检查网络和接口配置。" }
                finally { loading = false }
            }
        }, enabled = !loading, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Red), shape = RoundedCornerShape(14.dp)) {
            if (loading) { CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp); Text("正在生成…", modifier = Modifier.padding(start = 8.dp)) } else { Icon(Icons.Default.AutoAwesome, null); Text(" 生成小红书笔记", fontWeight = FontWeight.Bold) }
        }
        if (error.isNotBlank()) Text(error, color = Red, fontSize = 12.sp)
        if (result.isNotBlank()) {
            Surface(color = Color.White, shape = RoundedCornerShape(17.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) { Text("生成结果", fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.weight(1f)); TextButton(onClick = { onSave(Post(keyword, result, topic, java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date()))) }) { Text("保存笔记", color = Red) } }
                    SelectionContainer { Text(result, color = Ink, fontSize = 13.sp, lineHeight = 21.sp) }
                }
            }
        }
        Text("AI生成内容只是草稿。发布前请核验事实、亲自试用工具，并遵守平台规则。", color = Muted, fontSize = 11.sp)
    }
}

suspend fun callChatApi(base: String, model: String, apiKey: String, prompt: String): String = withContext(Dispatchers.IO) {
    val endpoint = base.trimEnd('/') + "/chat/completions"
    val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"; connectTimeout = 20000; readTimeout = 60000; doOutput = true
        setRequestProperty("Content-Type", "application/json")
        setRequestProperty("Authorization", "Bearer $apiKey")
    }
    try {
        val body = JSONObject().put("model", model).put("messages", JSONArray().put(JSONObject().put("role", "system").put("content", "你是一个重视真实性、可执行性和合规性的内容策略助手。使用简体中文。" )).put(JSONObject().put("role", "user").put("content", prompt))).put("temperature", 0.7)
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
        val response = stream.bufferedReader().use { it.readText() }
        if (conn.responseCode !in 200..299) throw IllegalStateException("接口返回 ${conn.responseCode}: ${response.take(500)}")
        JSONObject(response).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
    } finally { conn.disconnect() }
}

@Composable
fun AnalyticsScreen(metrics: List<Metric>, onAdd: () -> Unit, posts: List<Post>) {
    ScreenColumn {
        PageHeading("经营数据", "用数据决定下一篇做什么")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatCard("总浏览", metrics.sumOf { it.views }.toString(), "次", Modifier.weight(1f))
            StatCard("总涨粉", metrics.sumOf { it.followers }.toString(), "人", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatCard("总收藏", metrics.sumOf { it.saves }.toString(), "次", Modifier.weight(1f))
            StatCard("总收入", "¥" + String.format("%.2f", metrics.sumOf { it.income }), "元", Modifier.weight(1f))
        }
        Button(onClick = onAdd, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Red), shape = RoundedCornerShape(13.dp)) { Icon(Icons.Default.Add, null); Text(" 记录一次数据") }
        Text("数据记录", color = Ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        if (metrics.isEmpty()) EmptyState("还没有数据", "发布笔记后，把浏览、点赞、收藏和收入记录在这里。")
        metrics.asReversed().forEach { m ->
            Surface(color = Color.White, shape = RoundedCornerShape(15.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text(m.date, color = Ink, fontWeight = FontWeight.Bold)
                    Text("浏览 ${m.views} · 点赞 ${m.likes} · 收藏 ${m.saves} · 涨粉 ${m.followers}", color = Muted, fontSize = 12.sp)
                    Text("收入 ¥${String.format("%.2f", m.income)}", color = Green, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
        Text("已保存的创作（${posts.size}）", color = Ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        posts.take(5).forEach { p -> Surface(color = Color.White, shape = RoundedCornerShape(13.dp)) { Column(Modifier.padding(13.dp)) { Text(p.title, color = Ink, fontWeight = FontWeight.SemiBold); Text("${p.topic} · ${p.date}", color = Muted, fontSize = 10.sp) } } }
    }
}

@Composable
fun EmptyState(title: String, desc: String) { Surface(color = Color.White, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.Inbox, null, tint = Muted, modifier = Modifier.size(30.dp)); Text(title, color = Ink, fontWeight = FontWeight.Bold); Text(desc, color = Muted, fontSize = 11.sp) } } }

@Composable
fun AddMetricDialog(onDismiss: () -> Unit, onSave: (Metric) -> Unit) {
    var date by remember { mutableStateOf(java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())) }
    var views by remember { mutableStateOf("") }; var likes by remember { mutableStateOf("") }; var saves by remember { mutableStateOf("") }; var followers by remember { mutableStateOf("") }; var income by remember { mutableStateOf("0") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("记录笔记数据") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            OutlinedTextField(date, { date = it }, label = { Text("日期") }, singleLine = true)
            OutlinedTextField(views, { views = it }, label = { Text("浏览量") }, singleLine = true)
            OutlinedTextField(likes, { likes = it }, label = { Text("点赞") }, singleLine = true)
            OutlinedTextField(saves, { saves = it }, label = { Text("收藏") }, singleLine = true)
            OutlinedTextField(followers, { followers = it }, label = { Text("新增粉丝") }, singleLine = true)
            OutlinedTextField(income, { income = it }, label = { Text("收入（元）") }, singleLine = true)
        }
    }, confirmButton = { TextButton(onClick = { onSave(Metric(date, views.toIntOrNull() ?: 0, likes.toIntOrNull() ?: 0, saves.toIntOrNull() ?: 0, followers.toIntOrNull() ?: 0, income.toDoubleOrNull() ?: 0.0)) }) { Text("保存") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } })
}

private fun loadPosts(p: android.content.SharedPreferences): List<Post> = try { val a = JSONArray(p.getString("posts", "[]")); (0 until a.length()).map { val o = a.getJSONObject(it); Post(o.optString("title"), o.optString("body"), o.optString("topic"), o.optString("date")) } } catch (_: Exception) { emptyList() }
private fun savePosts(p: android.content.SharedPreferences, list: List<Post>) { val a = JSONArray(); list.forEach { a.put(JSONObject().put("title", it.title).put("body", it.body).put("topic", it.topic).put("date", it.date)) }; p.edit().putString("posts", a.toString()).apply() }
private fun loadMetrics(p: android.content.SharedPreferences): List<Metric> = try { val a = JSONArray(p.getString("metrics", "[]")); (0 until a.length()).map { val o = a.getJSONObject(it); Metric(o.optString("date"), o.optInt("views"), o.optInt("likes"), o.optInt("saves"), o.optInt("followers"), o.optDouble("income")) } } catch (_: Exception) { emptyList() }
private fun saveMetrics(p: android.content.SharedPreferences, list: List<Metric>) { val a = JSONArray(); list.forEach { a.put(JSONObject().put("date", it.date).put("views", it.views).put("likes", it.likes).put("saves", it.saves).put("followers", it.followers).put("income", it.income)) }; p.edit().putString("metrics", a.toString()).apply() }

@Composable
fun SettingsDialog(base: String, model: String, key: String, onDismiss: () -> Unit, onSave: (String, String, String) -> Unit) {
    var b by remember { mutableStateOf(base) }
    var m by remember { mutableStateOf(model) }
    var k by remember { mutableStateOf(key) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("AI接口设置") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("支持 OpenAI 兼容的 Chat Completions 接口。API Key 仅保存在本机加密存储中。", color = Muted, fontSize = 11.sp)
                OutlinedTextField(b, { b = it }, label = { Text("API Base URL") }, singleLine = true)
                OutlinedTextField(m, { m = it }, label = { Text("模型名称") }, singleLine = true)
                OutlinedTextField(k, { k = it }, label = { Text("API Key") }, singleLine = true)
                Text("默认地址：https://api.openai.com/v1。使用第三方服务时，请确认其隐私和收费政策。不要把密钥分享给他人。", color = Muted, fontSize = 10.sp)
            }
        },
        confirmButton = { TextButton(onClick = { onSave(b.trim(), m.trim(), k.trim()) }) { Text("保存设置") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } }
    )
}
